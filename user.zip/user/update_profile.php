<?php
//$var=$_GET['cat'];
session_start();
$var=$_SESSION['id'];
include 'database.php';
if(isset($_POST["submit"]))
{
	echo "Hello World";
	$v=$_POST['name'];
	$t=$_POST['id'];
    $a=$_POST['add'];
	
	$sql = "UPDATE registration SET name='$v', Address='$a' WHERE id='$t'";
	if (mysqli_query($conn, $sql)) 
	{
		header("Location:home.php");
        alert("data is changed sucessfully");
	}
	else
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>
<html>
<head>
</head>
<body>
<form method="post">
<?php
$records = mysqli_query($conn,"SELECT * FROM registration where id='$var'");
while($data = mysqli_fetch_array($records))
{
?>
	<input type="text" value="<?php echo $data['id'];?>" readonly name="id"><br>
	<input type="text" value="<?php echo $data['name'];?>" name="name"><br>
    <input type="text" value="<?php echo $data['Address'];?>" name="add"><br>
	<input type="submit" name="submit" value="Update">
<?php
}
?>
</form>
</body>
</html>